SkillPoints for Brick by Brick
https://github.com/michel86ch-ui/brickbybrick-mod-skillpoints

INSTALL
Unzip everything into the game folder, so that winhttp.dll sits next to BrickByBrick.exe
(Steam: right-click the game > Manage > Browse local files). BepInEx already installed
(e.g. with Extra Buildings)? Just overwrite, the files are the same.

USE
In a world you host, press F10: +10 skill points. Key and amount are in
BepInEx\config\michel.brickbybrick.skillpoints.cfg (created at the first game start).
Note: once used, the game no longer counts that world for the Steam leaderboard.

UNINSTALL
Delete the folder BepInEx\plugins\SkillPoints.

Includes BepInEx 5.4.23.5, unmodified (MIT license: BepInEx\LICENSE-BepInEx.txt).
Unofficial fan mod, not made by the game's developers.
